package src
	// var msg interface{} = "Welcome Hesham Mahmoud"
	// // Type Assertion
	// message := msg.(string)
	// // num := msg.(int) Panic
	// fmt.Println(message)

	// num , ok := msg.(int)
	// if ok { 
	// 	fmt.Println(num)
	// }else{ 
	// 	fmt.Println("Error .. ")
	// }
