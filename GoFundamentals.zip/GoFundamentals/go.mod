module ma-app

go 1.27.0
