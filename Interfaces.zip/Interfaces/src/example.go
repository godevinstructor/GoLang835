package src

import (
	"math"
)

type Shape interface {
	Area() float64
	// Perimeter() float64
}
type Rectangle struct {
	Length float64
	Width float64
}
type Square struct {
	Side float64
}
func (sq Square) Area() float64 { 
	return math.Pow(sq.Side , 2)
}
func (rect Rectangle) Area() float64 { 
	return rect.Length * rect.Width
}

// Calc Total areas 
func CalcTotalAreas(shapes []Shape) float64 { 
	total := 0.0
	for _ , sh := range shapes { 
		total += sh.Area()
	}
	return total
}

func FindLargestShape(shapes []Shape) Shape { 
	var largestShape Shape // nil
	for _ , sh := range shapes { 
		if largestShape == nil || sh.Area() > largestShape.Area() {
			largestShape = sh
		}
	}
	return  largestShape
}

// func main() {
// 	shapes := []Shape{
// 		Square{Side : 5} , 
// 		Rectangle{Length: 4 , Width: 8},
// 	}
// 	fmt.Println(CalcTotalAreas(shapes))
// 	fmt.Println(FindLargestShape(shapes))
// }