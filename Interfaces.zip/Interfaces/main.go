package main

import (
	"fmt"
	// "go/types"
)

// func Max[T cmp.Ordered](x , y T) T {
// 	if x > y {
// 		return x
// 	}
// 	return y
// }

// func Search[T comparable](sl []T , item T) bool {
// 	for _ , v := range sl {
// 		if v == item {
// 			return true
// 		}
// 	}
// 	return false
// }

// function testFunc(i interface{}) {}
type Square struct { 
	Side int 
}

func TestFunc(i interface{}) { 
	switch v:= i.(type) { 
		case int : 
			fmt.Println(v)
		case float64 :
			fmt.Println(v)
		case Square :
			fmt.Println(v.Side)
		default:
			fmt.Println("Mustafa Ashraf")
	}
}

// Return Min Or Max Number func(a , b T)
func main() {
	//  Types Switches => Asseting Againt Many Types
}