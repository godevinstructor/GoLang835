package src

func Test() {
	// Map
	// Syntax map[keyvalue]valuType
	// student := map[string]string{
	// 	"id":   "1",
	// 	"name": "Mustafa Ashraf",
	// }
	// fmt.Println(student)
	//student := map[string]string{}
	// student["id"] = "1"
	// fmt.Println(student) // ??

	// var studentt map[string]string
	// student := make(map[string]string, 2)
	// student["id"] = "1"
	// student["name"] = "Ahmed"
	// student["points"] = "100"

	// std , ok := student["ahmed"]
	// fmt.Println(std, ok) // true or false

	// delete()

	// keys := make([]string , 0 , len(student))

	// for k := range student {
	// 	keys = append(keys, k)
	// }

	// sort.Strings(keys)
	// for _ , k := range keys {
	// 	fmt.Println(k , student[k])
	// }

	// for k, v := range student {
	// 	fmt.Println(k, v) // Key : value
	// }

	// fmt.Println(student , len(student))
	// Iterate Over Map
	// Sort Map
	// sort.Strings(keys)
	// Iterate
	// Sort Keys
	// Iterate to print values
}

// Week 6.2 Week 7.1 7.2 8.1
// Friday 18/9 From 5 Pm to Sun 5 pm
// Output + Solving +
