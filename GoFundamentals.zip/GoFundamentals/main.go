package main

import "fmt"

func handleError() {
	if r := recover(); r != nil {
		fmt.Print("Something Went Wrong ", r)
	}
}

func main() {
	// must place inside defer
	// defer handleError()
	panic("Error")
}
