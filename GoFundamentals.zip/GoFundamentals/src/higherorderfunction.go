package src

import "fmt"

// Higher Order Function
// func testOp(num int, f func(int) int) int {
// 	return f(num)
// }

// func counter() func() int {
// 	c := 0
// 	return func() int {
// 		c++
// 		return c
// 	}
// }
// [1 , 2 , 3 , 4] => [2 , 4 , 6 , 8]
// [3 , 4]
// 10 Reduce (int) string sum  

func mapIntNums(nums []int, f func(int) int) []int {
	result := make([]int, len(nums))
	for index, num := range nums {
		result[index] = f(num)
	}
	return result
}

func filterIntNums(nums []int, predicate func(int) bool) []int {
	var result []int // nil
	for _, num := range nums {
		if predicate(num) {
			result = append(result, num)
		}
	}
	return result
}

func redcuceIntNums(nums[]int , initial int , 
	reducer func(acc , curr int) int) int { 
		acc := initial
		for _ , v := range nums { 
			acc = reducer(acc , v)
		}
		return  acc
}

func HigherOrder() {
	nums := []int{10, 20, 80 , 30, 40}
	// Max Number 
	max := redcuceIntNums(nums , nums[0] , func(acc , curr int) int { 
		if(curr > acc) { 
			return curr
		}
		return acc
	})
	fmt.Println(max)
	// Sum 
	add := redcuceIntNums(nums , 0 , func(acc , curr int) int {
		return acc + curr
	})
	fmt.Println(add)
	// positiveNumbers := filterIntNums(nums, func(v int) bool {
	// 	return v > 0
	// })
	// fmt.Println(positiveNumbers) // [10 , 40]

	// nums := []int {10 , 20, 30, 40}
	// doubled := mapIntNums(nums , func(num int) int {return num * 2})
	// fmt.Println(doubled)
	// double := func(num int) int { return num * num }
	// mulByFour := func(num int) int {
	// 	return num * 4
	// }
	// fmt.Println(testOp(8 , double))
	// fmt.Println(testOp(10 , mulByFour))
	// greeting := func() string {
	// 	return "Welcome"
	// }

	// greeting()
}
