package src
// // The Problem
// // func sumFloatNumbers(nums []float64) float64 {
// // 	total := 0.0
// // 	for _, num := range nums {
// // 		total += num
// // 	}
// // 	return total
// // }
// func sumIntNumbers(nums []int) int {
// 	total := 0
// 	for _, num := range nums {
// 		total += num
// 	}
// 	return total
// }

// // Reusable Across All Functions
// type Number interface {
// 	int | float32 | float64 | int64 | int32 | int8
// }

// func sumNumbers[T Number](nums []T) T {
// 	var total T
// 	for _, num := range nums {
// 		total += num
// 	}
// 	return total
// }

// // func sumNumbers[T int | float64 | float32](nums []T) T {
// // 	var total T
// // 	for _, num := range nums {
// // 		total += num
// // 	}
// // 	return  total
// // }

// // any alias interface{}
// // func PrintValue[T any](v T) {
// // 	fmt.Println(v)
// // }