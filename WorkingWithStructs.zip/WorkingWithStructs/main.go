package main

import "fmt"

func divide(x, y int) {
	defer func() {
		if v := recover(); v != nil {
			fmt.Println("Bad Error ", v)
		}
	}()
	if y == 0 {
		panic("Respect Please ! Cannot Divide By Zero")
	}
	fmt.Println(x / y)
}
func main() {
	divide(10, 0)
	num := 10
	fmt.Println("Mostafa Ashraf", num)
}
