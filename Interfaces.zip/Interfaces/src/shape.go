package src

// type Shape interface {
// 	Area() float64
// 	Perimeter() float64
// }

// type Circle struct {
// 	Radius float64
// }
// type Rectangle struct { 
// 	Length float64
// 	Width float64
// }

// func (c Circle) Area() float64 {
// 	return math.Pi *  math.Pow(c.Radius , 2)
// }
// func (c Circle) Perimeter() float64 {
// 	return math.Pi *  2 * math.Pi
// }

// func (rect Rectangle) Area() float64 {
// 	return rect.Length * rect.Width
// }
// func (rect Rectangle) Perimeter() float64 {
// 	return (rect.Length + rect.Width) * 2
// }

// // Print Area()
// func PrintInfo(s Shape) {
// 	fmt.Println("Area " , s.Area())
// }

// func main() {
// 	c:= Circle {Radius: 8}
// 	rect := Rectangle{Length : 5 , Width: 6}
// 	PrintInfo(c)
// 	PrintInfo(rect)

// }