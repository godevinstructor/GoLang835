// interface Shape { 
//     area() : number;
// }

// class Square implements Shape { 

// }