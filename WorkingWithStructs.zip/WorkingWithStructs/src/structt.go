package src

// import (
// 	"fmt"
// 	"encoding/json"
// )

// Struct Vs Class
// Instances (Strcut Values)
// Add Methods To Structs
// Recievers (Value / Pointer)
// Anonymous Struct
// Embeded (Composition)
// Struct Tags (JSon) encoding/json (Meta Data String Attached Fields)
// Uppercase => public
// Lowercase => Private
// type Address struct {
// 	street  string
// 	city    string
// 	country string
// }

// type Person struct {
// 	name string
// 	age  int
// }

// type Doctor struct {
// 	Person
// 	Address
// }

// type Engineer struct {
// 	Person
// 	Address
// }

// // Value Reciever
// func (p Person) printName() {
// 	fmt.Println(p.name)
// }

// type Square struct {
// 	side int
// }

// func (self Square) perimeter() int {
// 	return self.side * 4
// }

// type Rectangle struct {
// 	Length float64
// 	Width  float64
// }

// // value reciever
// func (r Rectangle) Area() float64 {
// 	return r.Width * r.Length
// }

// // // pointer reciver
// // func (r *Rectangle) ScaleFields(v float64) {
// // 	r.Width *= v
// // 	r.Length *= v
// // }

// // Structs With Nested Data
// type ProjectTeam struct {
// 	Name string
// 	Num  int
// 	Members [] string
// }

// type User struct {
// 	Username string `json:"username"`
// 	Email string    `json:"email"`
// 	Password string `json:"password"`
// 	PhoneNumber string `json:"phone,omitempty"` // omit if zero value
// }

// 	// '{"" : ""}'
// 	user := User{Username: "Amgad" , Email: "Amgad@amgad.com" ,
// 	Password: "12345" , PhoneNumber: "123457567567",}
// 	data , _ := json.Marshal(user)
// 	fmt.Println(string(data))
// 	// if err != nil {
// 	// 	fmt.Println(string(data))
// 	// }

// 	// pt := ProjectTeam{
// 	// 	Name : "" ,
// 	// 	Num : 1 ,
// 	// 	Members: []string{"Amgad" , "Ali" , "Mostafa"},
// 	// }
// 	// fmt.Println(pt.Members[0])
// 	// car := struct{ name string }{name: "Bmw"}
// 	// fmt.Println(car)

// 	// p1 := Person{"ali", 29}
// 	// p2 := Person {"ali" , 29}
// 	// fmt.Println(p1 == p2)
// 	// rect := Rectangle{Width: 50, Length: 100}
// 	// rect.ScaleFields(2)
// 	// fmt.Println(rect.Area())
// 	// sq := Square{8}
// 	// fmt.Println(sq.perimeter())
// 	// p := Person {"Ahmed" , 40}
// 	// p.printName()
// 	// p1 := Person {name : "ahmed" , age : 12}
// 	// p2 := Person {"abc" , 40}
// 	// p := p1
// 	// p.name = "Ali"
// 	// var p Person
// 	// // p1 {ahmed , 12}
// 	// // p {ali , 12}
// 	// fmt.Println(p2 , p1 , p)
// 	// Return Pointer
// 	// p := new(Person)
// 	// p.name = "John"
// 	// p.age = 30
// 	// per := p
// 	// per.name = "Jack"
// 	// fmt.Println(p , per)
